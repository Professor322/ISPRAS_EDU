1) Create set of subformulas
   1) Enable lexer and parser for formulas
2) Create truth table
3) Create closure of classic vibes
4) Create closure of temporal vibes
5) Mark initial and finish states
6) Create edges

