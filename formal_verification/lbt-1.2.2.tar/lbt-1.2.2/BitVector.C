// -*- c++ -*-
/// @file BitVector.C

#ifdef __GNUC__
# pragma implementation
#endif // __GNUC__
#include "BitVector.h"
